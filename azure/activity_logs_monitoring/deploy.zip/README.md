# Datadog-Azure function

The Datadog-Azure function is used to forward Azure logs to Datadog, including Activity and Diagnostic logs from EventHub.

## See our documentation: [Send Azure Logs to Datadog](https://docs.datadoghq.com/logs/guide/azure-logging-guide/).
